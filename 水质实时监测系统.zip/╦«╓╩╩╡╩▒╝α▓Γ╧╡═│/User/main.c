#include "System.h"                  // Device header
#include "ds18b20.h"
#include "stdio.h"
#include <stdlib.h>
#include <string.h>
#include "TFT_LCD.h"
#include "ADC.h"
#include "esp8266.h"
#include "OneNET.h"
#include "TIM.h"

#define STDE 2000 //��׼��ѹ(mV)
#define STDPH 6.86 //��׼pHֵ
#define DETA_PH(v, t) 293 * (v - STDE) / ((-58.16) * (273 + t))//�����pHֵ�Ĺ�ʽ

//PHֵ���㹫ʽ:pH = 6.86 + DETA_PH(value, temperature)

void Connect_OneNET(void);
void TIM3_Update(void);

char str[20];

OneNET_MQTT_InitTypDef OneNET_MQTT_InitStructure;
//��ƽ̨MQTT��ʼ������
OneNET_MQTT_DataFormat OneNET_MQTT_TEMP;
OneNET_MQTT_DataFormat OneNET_MQTT_PH;
OneNET_MQTT_DataFormat OneNET_MQTT_Dirty;

int main(void)
{
	TFT_LCD_Init();
	DS18B20_GPIO_Init();
	ADC_Config_Init();
	USART1_Config_Init(115200);
	esp8266_GPIO_Init(115200);
	Connect_OneNET();
	TIM3_Init(36000, 8000);
	//timeout = 36000 * 8000 / 72MHz = 3s
	
	strcpy(OneNET_MQTT_TEMP.TAG,"TEMP");
	strcpy(OneNET_MQTT_PH.TAG, "PH");
	strcpy(OneNET_MQTT_Dirty.TAG, "Dirty");
//	OneNET_MQTT_TEMP._d = 26;
//	OneNET_MQTT_SendData(_double, &OneNET_MQTT_TEMP);
	
	TFT_LCD_Clear();
	while(1)
	{
		OneNET_MQTT_TEMP.DataType._double = DS18B20_ReadTEMP();
		//��ȡ�¶�
		memset(str, 0, sizeof(str));
		//����ַ���
		sprintf(str, "TEMP:%.1f        ", OneNET_MQTT_TEMP.DataType._double);
		//��ӡ�ַ���,��ͬ
		TFT_LCD_ShowString(8*0, 16*0, str, Font8x16, WHITE);
		
		ADC_GetValue(ADC_Channel_0);
		//�ɼ�ͨ��0ǰ������һ�¸ú���,��ֹ�ɼ�����
		OneNET_MQTT_PH.DataType._double = (double)ADC_GetValue(ADC_Channel_0) / 4095 * 3300;
		//�ȱ���ADת����ģ����
		OneNET_MQTT_PH.DataType._double = 6.86 + DETA_PH(OneNET_MQTT_PH.DataType._double, OneNET_MQTT_TEMP.DataType._double);
		//��ģ����ת��ΪPH�洢�ڱ�����
		memset(str, 0, sizeof(str));
		sprintf(str, "PH:%.1f        ", OneNET_MQTT_PH.DataType._double);
		TFT_LCD_ShowString(8*0, 16*1, str, Font8x16, WHITE);
		
		ADC_GetValue(ADC_Channel_1);
		OneNET_MQTT_Dirty.DataType._unsigned_int = (double)ADC_GetValue(ADC_Channel_1) / 4095 * 3300;
		
		memset(str, 0, sizeof(str));
		sprintf(str, "~Dirty:%u        ", OneNET_MQTT_Dirty.DataType._unsigned_int);
		TFT_LCD_ShowString(8*0, 16*2, str, Font8x16, WHITE);
		
		if(OneNET_MQTT_State_Reg.Flag.SUB == 1)
		{
			TFT_LCD_ShowString(8*0, 16*4, "SUB OK ", Font8x16, WHITE);
		}
		else
		{
			TFT_LCD_ShowString(8*0, 16*4, "SUB ERR", Font8x16, WHITE);
		}
		//������Ϣ״̬������Ļ���±���ʾ
		TIM3_Update();
	}
}

void Connect_OneNET(void)
{
	TFT_LCD_ShowString(8*0, 16*0, "esp init...", Font8x16, WHITE);
	AP_Inf_struct AP_Inf;
	OneNET_MQTT_InitTypDef OneNET_Inf;
	AP_Inf.WIFI_CODE = "wwx12345";
	AP_Inf.WIFI_NAME = "XIAOXINPRO6";
	strcpy(OneNET_Inf.Device_ID, "STM32F103ZET6");
	strcpy(OneNET_Inf.PassWord,"version=2018-10-31&res=products%2Fd49QLs085J%2Fdevices%2FSTM32F103ZET6&et=2810330682&method=md5&sign=%2BdV99iCYuDreDYy6K7VAeg%3D%3D");
	strcpy(OneNET_Inf.Product_ID,"d49QLs085J");
	
	esp8266_AT_START();
	if(Esp_Reg.Flag.AT)
	{
		TFT_LCD_ShowString(8*0, 16*1, "AT OK", Font8x16, WHITE);
	}
	else
	{
		TFT_LCD_ShowString(8*0, 16*1, "AT ERROR", Font8x16, WHITE);
	}
	esp8266_CWMODE_Choose(STA);
	if(Esp_Reg.Flag.STA)
	{
		TFT_LCD_ShowString(8*0, 16*2, "STA OK", Font8x16, WHITE);
	}
	else
	{
		TFT_LCD_ShowString(8*0, 16*2, "STA ERROR", Font8x16, WHITE);
	}
	esp8266_DHCP_Start();
	if(Esp_Reg.Flag.DHCP)
	{
		TFT_LCD_ShowString(8*0, 16*3, "DHCP OK", Font8x16, WHITE);
	}
	else
	{
		TFT_LCD_ShowString(8*0, 16*3, "DHCP ERROR", Font8x16, WHITE);
	}
	esp8266_JoinAP(&AP_Inf);
	if(Esp_Reg.Flag.WIFI)
	{
		TFT_LCD_ShowString(8*0, 16*4, "WIFI OK", Font8x16, WHITE);
	}
	else
	{
		TFT_LCD_ShowString(8*0, 16*4, "WIFI ERROR", Font8x16, WHITE);
	}
	
	TFT_LCD_Clear();
	
	OneNET_MQTT_Init(&OneNET_Inf);
	if(OneNET_MQTT_State_Reg.Flag.CFG == 1)
	{
		TFT_LCD_ShowString(8*0, 16*0, "OneNET CFG OK", Font8x16, WHITE);
	}
	else
	{ 
		TFT_LCD_ShowString(8*0, 16*0, "OneNET CFG ERR", Font8x16, WHITE);
	}
	if(OneNET_MQTT_State_Reg.Flag.CONN == 1)
	{
		TFT_LCD_ShowString(8*0, 16*1, "OneNET CONN OK", Font8x16, WHITE);
	}
	else
	{ 
		TFT_LCD_ShowString(8*0, 16*1, "OneNET CONN ERR", Font8x16, WHITE);
	}
	if(OneNET_MQTT_State_Reg.Flag.REPLY == 1)
	{
		TFT_LCD_ShowString(8*0, 16*2, "OneNET REPLY OK", Font8x16, WHITE);
	}
	else
	{ 
		TFT_LCD_ShowString(8*0, 16*2, "OneNET REPLY ERR", Font8x16, WHITE);
	}
	if((OneNET_MQTT_State_Reg.Flag_All & 0x07) && (Esp_Reg.Flag_All & 0x0f))
	{
		TFT_LCD_ShowString(8*0, 16*3, "Init OK", Font8x16, WHITE);
	}
	else
	{
		TFT_LCD_ShowString(8*0, 16*3, "Init ERR", Font8x16, WHITE);
	}
	Delay_ms(1000);
	//��ʾһ��
}

void TIM3_Update(void)
{
	if(TIM_GetFlagStatus(TIM3, TIM_FLAG_Update) == SET)
	{
		TIM_Cmd(TIM3, DISABLE);
		//�ȹر�TIM3
		TIM3->CNT = 0;
		//����������
		
		OneNET_MQTT_SendData(_double, &OneNET_MQTT_TEMP);
		//�����¶�
		OneNET_MQTT_SendData(_double, &OneNET_MQTT_PH);
		//����PH
		OneNET_MQTT_SendData(_int, &OneNET_MQTT_Dirty);
		//���ͻ��Ƕ�
		
		//����ƽ̨������Ϣ
		
		TIM_Cmd(TIM3, ENABLE);
		//����TIM3
		
		TIM_ClearFlag(TIM3, TIM_FLAG_Update);
	}
}
