#ifndef __ESP8266_H
#define __ESP8266_H

#include "System.h"
#include "USART.h"

#define ESP_RST_Pin GPIO_Pin_4
#define ESP_EN_Pin GPIO_Pin_5

#define ESP_RST_Pin_Set GPIOA->BSRR = ESP_RST_Pin
#define ESP_RST_Pin_Reset GPIOA->BRR = ESP_RST_Pin
#define ESP_EN_Pin_Set GPIOA->BSRR = ESP_EN_Pin
#define ESP_EN_Pin_Reset GPIOA->BRR = ESP_EN_Pin

typedef enum{
	Power_off = 0,
	Power_on
}enum_work_typdef;

typedef enum{
	STA = 1,
	AP,
	STA_AP
}enum_CWMODE_typdef;

typedef struct{
	char* WIFI_NAME;
	char* WIFI_CODE;
}AP_Inf_struct;

extern union Esp_Reg_Union
{
	u8 Flag_All;
	struct
	{
		volatile bool AT : 1;	//0
		volatile bool STA : 1;	//1
		volatile bool DHCP : 1;	//2
		volatile bool WIFI : 1;	//3
	}Flag;
}Esp_Reg;

void esp8266_GPIO_Init(u32 bound);
void esp8266_RST(void);
void esp8266_CH_PD(enum_work_typdef mode);
bool esp8266_AT_Cmd(char* ack, char* cmd, ...);
bool esp8266_AT_START(void);
bool esp8266_CWMODE_Choose(enum_CWMODE_typdef CWMODE);
bool esp8266_DHCP_Start(void);
bool esp8266_JoinAP(AP_Inf_struct* AP_Inf);

#endif
