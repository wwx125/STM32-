#ifndef __TIM_H
#define __TIM_H

#include "System.h"                  // Device header

void TIM3_Init(u16 ARR, u16 PSC);

#endif
