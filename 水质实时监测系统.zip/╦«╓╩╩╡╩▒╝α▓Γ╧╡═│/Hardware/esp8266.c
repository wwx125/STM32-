#include "esp8266.h"

union Esp_Reg_Union Esp_Reg;

void esp8266_GPIO_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = ESP_RST_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = ESP_EN_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART2_Config_Init(bound);
	
	esp8266_CH_PD(Power_on);
	
	ESP_RST_Pin_Set;
	
	USART_Cmd(USART2, ENABLE);
	
	_USART2.RECEIVE_OK_FLAG = 0;
	
	esp8266_RST();
	
	Delay_ms(1000);
	
	while(!_USART2.RECEIVE_OK_FLAG);
	
	memset(_USART2.rec_data_arry, 0, sizeof(_USART2.rec_data_arry));
	
	Delay_ms(1000);
}

void esp8266_RST(void)
{
	ESP_RST_Pin_Reset;
	Delay_ms(500);
	ESP_RST_Pin_Set;
}

void esp8266_CH_PD(enum_work_typdef mode)
{
	if(mode == Power_off)
	{
		ESP_EN_Pin_Reset;
	}
	else
	{
		ESP_EN_Pin_Set;
	}
}

bool esp8266_AT_Cmd(char* ack, char* cmd, ...)
{
	char cnt = 3;
	char str[300] = {0};
	
	va_list func_p;
	//����һ������ָ��
	va_start(func_p, cmd);
	//ָ���һ������
	vsprintf(str, cmd, func_p);
	//��vsprintf��ӡ��str
	va_end(func_p);
	//�������ָ��
	_USART2.RECEIVE_OK_FLAG = 0;
	//���������ɱ�־λ
	
	memset(_USART2.rec_data_arry, 0, sizeof(_USART2.rec_data_arry));
	//�����������
	USART2_SendString("%s\r\n", str);
	//��������
	while(!_USART2.RECEIVE_OK_FLAG);
	//�ȴ���Ӧ
	if(ack == NULL)
	{
		return 1;
	}
	//û����Ӧ�������ֱ�ӷ���1
	if(strstr(_USART2.rec_data_arry, ack) != NULL)
	{
		return (bool)strstr(_USART2.rec_data_arry, ack);
	}
	//�鿴�Ƿ�ΪԤ�ڵ���Ӧ
	
	while(cnt)
	{
		cnt --;
		Delay_ms(1000);
		if(strstr(_USART2.rec_data_arry, ack) != NULL)
		{
			break;
		}
		USART2_SendString("%s\r\n", str);
		//��������
		_USART2.RECEIVE_OK_FLAG = 0;
		while(!_USART2.RECEIVE_OK_FLAG);
	}
	
	return (bool)strstr(_USART2.rec_data_arry, ack);
}

bool esp8266_AT_START(void)
{
	Esp_Reg.Flag.AT = esp8266_AT_Cmd("OK", "AT");
	return Esp_Reg.Flag.AT;
}

bool esp8266_CWMODE_Choose(enum_CWMODE_typdef CWMODE)
{
	switch(CWMODE)
	{
		case STA:
			Esp_Reg.Flag.STA = esp8266_AT_Cmd("OK", "AT+CWMODE=1");
		break;
		case AP:
			Esp_Reg.Flag.STA = esp8266_AT_Cmd("OK", "AT+CWMODE=2");
		break;
		case STA_AP:
			Esp_Reg.Flag.STA = esp8266_AT_Cmd("OK", "AT+CWMODE=3");
		break;
	}
	return Esp_Reg.Flag.STA;
}

bool esp8266_DHCP_Start(void)
{
	Esp_Reg.Flag.DHCP = esp8266_AT_Cmd("\r\n", "AT+CWDHCP=1,1");
	return Esp_Reg.Flag.DHCP;
}

bool esp8266_JoinAP(AP_Inf_struct* AP_Inf)
{
	Esp_Reg.Flag.WIFI = esp8266_AT_Cmd("OK", "AT+CWJAP=\"%s\",\"%s\"", AP_Inf->WIFI_NAME, AP_Inf->WIFI_CODE);
	return Esp_Reg.Flag.WIFI;
}
