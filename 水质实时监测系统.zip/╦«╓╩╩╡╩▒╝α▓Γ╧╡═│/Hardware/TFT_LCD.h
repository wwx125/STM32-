#ifndef __TFT_LCD_H
#define __TFT_LCD_H

//cmd table
#define Sleep_In					0x10
#define Sleep_Out					0x11
#define Display_Off					0x28
#define Display_On					0x29

#define CASET						0x2A//column address set cmd
#define RASET						0x2B//row address set cmd
#define Memory_Write				0x2C//before we write data, we should use this cmd

#define Memory_Data_Access_Control	0x36//row, column, RGB and scan mode control cmd
#define Interface_Pixel_Format		0x3A//choose RGB resolution ratio
#define Frame_rate_control_1		0xB1//in normal mode
#define Frame_rate_control_2		0xB2//in idle mode
#define Frame_rate_control_3		0xB3//in partial mode
#define Display_inversion_control	0xB4//
#define Power_control_1				0xC0//
#define Power_control_2				0xC1//set VGH and VGL supply power level
#define Power_control_3				0xC2//in normal mode
#define Power_control_4				0xC3//in idle mode
#define Power_control_5				0xC4//in partial mode
#define VCOM_control_1				0xC5//change VCOM voltage level.
#define VCOM_Offset_Cntrol			0xC7//to reduce the filcker issue
#define NVM_control_status			0xD9

// Color define
#define BLACK	0x00000000
#define RED		0x00FF0000
#define GREEN	0x0000FF00
#define BLUE	0x000000FF
#define YELLOW	0x00FFFF00
#define SKYBLUE	0x00F0FFFF
#define CYAN	0x0000FFFF
#define WHITE	0x00FFFFFF
//This Color Value sequence is RGB,which 'R' is the most significant bit(MSB).
//
typedef enum{
	Font8x16 = 0,
	Font16x16
}TypdefFontSize;

void TFT_LCD_Init(void);
void TFT_LCD_Clear(void);
void TFT_LCD_Fill_Color(uint16_t XS, uint16_t XE, uint16_t YS, uint16_t YE, uint32_t Color);
void TFT_LCD_ShowChar(uint16_t XS, uint16_t YS, char Char, TypdefFontSize SizeofChar, uint32_t Color);
void TFT_LCD_ShowString(uint16_t XS, uint16_t YS, char *String, TypdefFontSize SizeofChar, uint32_t Color);
void TFT_LCD_ShowNum(uint16_t XS, uint16_t YS, uint32_t Num, uint8_t Length, TypdefFontSize SizeofChar, uint32_t Color);
void TFT_LCD_ShowSignNum(uint16_t XS, uint16_t YS, long Num, uint8_t Length, TypdefFontSize SizeofChar, uint32_t Color);
void TFT_LCD_ShowBinNum(uint16_t XS, uint16_t YS, uint16_t Num, uint16_t Length, TypdefFontSize SizeofChar, uint32_t Color);
#endif
