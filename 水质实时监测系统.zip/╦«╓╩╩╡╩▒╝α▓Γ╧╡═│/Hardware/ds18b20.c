#include "ds18b20.h"

bool ds18b20_init_status;
ds18b20_data_struct ds18b20_data;
volatile double TEMP;

void DS18B20_GPIO_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;//
	GPIO_InitStructure.GPIO_Pin = DS18B20_GPIO_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	DS18B20_Pwr = 1;
}

void DS18B20_Init(void)//
{
	DS18B20_Pwr = 0;
	Delay_us(500);
	DS18B20_Pwr = 1;
	Delay_us(200);
	ds18b20_init_status = DS18B20_Prd;
	Delay_us(400);
	
}

//DS18B20_WriteBit(0);
void DS18B20_WriteBit(bool bit)
{
	DS18B20_Pwr = 0;
	Delay_us(5);
	DS18B20_Pwr = bit;
	Delay_us(50);
	DS18B20_Pwr = 1;
	Delay_us(1);
	//
}

// temp = DS18B20_ReadBit();
u8 DS18B20_ReadBit(void)
{
	bool bit = 0;
	DS18B20_Pwr = 0;
	Delay_us(5);
	DS18B20_Pwr = 1;
	//�ͷ�����
	Delay_us(5);
	bit = DS18B20_Prd;
	Delay_us(50);
	return bit;
}

//�����߷����������ɵ͵���
//eg. ����0x55 ������Ϊ 0101 0101 & 0000 0100
//
void DS18B20_WriteByte(u8 byte)
{
	u8 i = 0;
	for(i = 0; i < 8; i ++)
	{
		DS18B20_WriteBit(byte & (0x01 << i));
	}
}

//

u8 DS18B20_ReadByte(void)
{
	u8 byte = 0, i = 0;
	for(i = 0; i < 8; i ++)
	{
		if(DS18B20_ReadBit())
			byte |= (0x01 << i);
	}
	return byte;
}

void DS18B20_WriteROMCmd(ds18b20_rom_cmdEnum data)
{
	DS18B20_WriteByte(data);
}

void DS18B20_WriteRAMCmd(ds18b20_ram_cmdEnum data)
{
	DS18B20_WriteByte(data);
}

float DS18B20_ReadTEMP(void)
{
	u16 TEMP = 0;
	int sign = 1;
	DS18B20_Init();
	if(!ds18b20_init_status)
		return -1;
	DS18B20_WriteROMCmd(skip_rom_adr);
	DS18B20_WriteRAMCmd(TEMP_exchange);
	//�ȿ����¶�ת��
	DS18B20_Init();
	if(!ds18b20_init_status)
		return -1;
	DS18B20_WriteROMCmd(skip_rom_adr);
	DS18B20_WriteRAMCmd(read_ram);
	ds18b20_data.TEMP_LSB = DS18B20_ReadByte();
	ds18b20_data.TEMP_MSB = DS18B20_ReadByte();
	TEMP = ds18b20_data.TEMP_MSB;
	TEMP <<= 8;
	TEMP += ds18b20_data.TEMP_LSB;
	if(TEMP & 0xf000)
	{
		TEMP = ~TEMP + 1;
		sign = -1;
	}
	return (double)TEMP * 0.0625 * sign;
}

void DS18B20_Set_TEMP_Resolution_ratio(ds18b20_TEMP_format format)
{
	DS18B20_Init();
	if(!ds18b20_init_status)
		return;
	DS18B20_WriteROMCmd(skip_rom_adr);
	DS18B20_WriteRAMCmd(ram_config);
	DS18B20_WriteByte(0x50);
	DS18B20_WriteByte(0x05);
	DS18B20_WriteByte(format);
	ds18b20_data.TEMP_format = format;
}

void DS18B20_Read_RAM(void)
{
	DS18B20_Init();
	if(!ds18b20_init_status)
		return;
	DS18B20_WriteROMCmd(skip_rom_adr);
	DS18B20_WriteRAMCmd(read_ram);
	ds18b20_data.TEMP_LSB = DS18B20_ReadByte();
	ds18b20_data.TEMP_MSB = DS18B20_ReadByte();
	ds18b20_data.TEMP_TH = DS18B20_ReadByte();
	ds18b20_data.TEMP_TL = DS18B20_ReadByte();
	ds18b20_data.TEMP_format = DS18B20_ReadByte();
	ds18b20_data.Reserved_byte5 = DS18B20_ReadByte();
	ds18b20_data.Reserved_byte6 = DS18B20_ReadByte();
	ds18b20_data.Reserved_byte7 = DS18B20_ReadByte();
	ds18b20_data.ds18b20_crc = DS18B20_ReadByte();
}
