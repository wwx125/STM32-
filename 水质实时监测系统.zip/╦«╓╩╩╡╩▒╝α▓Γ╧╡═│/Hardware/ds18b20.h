#ifndef __DS18B20_H
#define __DS18B20_H

#include "System.h"
#include <stdbool.h>

#define DS18B20_GPIO_Pin GPIO_Pin_9
#define DS18B20_Pwr PBOut(9)
#define DS18B20_Prd PBIn(9)

extern bool ds18b20_init_status;
extern volatile double TEMP;

typedef enum{
	_9_bit = 0x1f,
	_10_bit = 0x3f,
	_11_bit = 0x5f,
	_12_bit = 0x7f			
}ds18b20_TEMP_format;

typedef enum{
	read_rom_adr = 0x33,
	rom_matching = 0x55,
	serch_rom_adr = 0xf0,
	skip_rom_adr = 0xcc,
	TEMP_alarm = 0xec
}ds18b20_rom_cmdEnum;

typedef enum{
	TEMP_exchange = 0x44,
	read_ram = 0xbe,
	ram_config = 0x4e,
	copy_temp = 0x48,
	reset_EEPROM = 0xb8,
	read_power = 0xb4
}ds18b20_ram_cmdEnum;

typedef struct{
	u8 TEMP_LSB;
	u8 TEMP_MSB;
	u8 TEMP_TH;
	u8 TEMP_TL;
	ds18b20_TEMP_format TEMP_format;
	u8 Reserved_byte5;
	u8 Reserved_byte6;
	u8 Reserved_byte7;
	u8 ds18b20_crc;
}ds18b20_data_struct;

extern ds18b20_data_struct ds18b20_data;

void DS18B20_GPIO_Init(void);
float DS18B20_ReadTEMP(void);
void DS18B20_Set_TEMP_Resolution_ratio(ds18b20_TEMP_format format);
void DS18B20_Read_RAM(void);

#endif
