#include "stm32f10x.h"                  // Device header
#include "TFT_LCD.h"
#include "TFT_LCD_Font.h"
#include "Delay.h"

#define TFT_LCD_W_SCL(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_3, (BitAction)(x))
#define TFT_LCD_W_DC(x)		GPIO_WriteBit(GPIOB, GPIO_Pin_4, (BitAction)(x))
#define TFT_LCD_W_SDA(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_5, (BitAction)(x))
#define TFT_LCD_R_SDA		GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5)
#define TFT_LCD_W_RES(x)	GPIO_WriteBit(GPIOB, GPIO_Pin_6, (BitAction)(x))
#define TFT_LCD_W_CS(x)		GPIO_WriteBit(GPIOB, GPIO_Pin_7, (BitAction)(x))

void TFT_LCD_GPIO_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	
	GPIO_SetBits(GPIOB, GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7);
}

void TFT_LCD_Write_Data(uint8_t Data)
{
	uint8_t i;
	TFT_LCD_W_CS(0);
	for(i = 0; i < 8; i ++)
	{
		TFT_LCD_W_SCL(0);
		if(i ==7)
			TFT_LCD_W_DC(1);
		if(Data & 0x80)
			TFT_LCD_W_SDA(1);
		else
			TFT_LCD_W_SDA(0);
		TFT_LCD_W_SCL(1);
		Data <<= 1;
	}
	TFT_LCD_W_CS(1);
}

void TFT_LCD_Write_Data_16Bit(uint16_t Data)
{
	TFT_LCD_Write_Data(Data >> 8);
	TFT_LCD_Write_Data(Data);
}

void TFT_LCD_Write_Data_24Bit(uint32_t Data)
{
	TFT_LCD_Write_Data(Data >> 16);
	TFT_LCD_Write_Data(Data >> 8);
	TFT_LCD_Write_Data(Data);
}

void TFT_LCD_Write_Command(uint8_t Command)
{
	uint8_t i;
	TFT_LCD_W_CS(0);
	for(i = 0; i < 8; i ++)
	{
		TFT_LCD_W_SCL(0);
		if(i ==7)
			TFT_LCD_W_DC(0);
		if(Command & 0x80)
			TFT_LCD_W_SDA(1);
		else
			TFT_LCD_W_SDA(0);
		TFT_LCD_W_SCL(1);
		Command <<= 1;
	}
	TFT_LCD_W_CS(1);
}

void TFT_LCD_Address_Set(uint16_t XS, uint16_t XE, uint16_t YS, uint16_t YE)
{
	TFT_LCD_Write_Command(CASET);
	TFT_LCD_Write_Data_16Bit(XS);
	TFT_LCD_Write_Data_16Bit(XE);
	TFT_LCD_Write_Command(RASET);
	TFT_LCD_Write_Data_16Bit(YS + 24);
	TFT_LCD_Write_Data_16Bit(YE + 24);
	TFT_LCD_Write_Command(Memory_Write);
}

void TFT_LCD_Init(void)
{
	TFT_LCD_GPIO_Init();
	
	TFT_LCD_W_RES(0);
	Delay_us(10);
	TFT_LCD_W_RES(1);
	Delay_ms(120);
	
	TFT_LCD_Write_Command(Sleep_Out);//
	
	TFT_LCD_Write_Command(Frame_rate_control_1);     
	TFT_LCD_Write_Data(0x05);   
	TFT_LCD_Write_Data(0x3C);   
	TFT_LCD_Write_Data(0x3C);   

	TFT_LCD_Write_Command(Frame_rate_control_2);     
	TFT_LCD_Write_Data(0x05);   
	TFT_LCD_Write_Data(0x3C);   
	TFT_LCD_Write_Data(0x3C);   

	TFT_LCD_Write_Command(Frame_rate_control_3);     
	TFT_LCD_Write_Data(0x05);   
	TFT_LCD_Write_Data(0x3C);   
	TFT_LCD_Write_Data(0x3C);   
	TFT_LCD_Write_Data(0x05);   
	TFT_LCD_Write_Data(0x3C);   
	TFT_LCD_Write_Data(0x3C);   

	TFT_LCD_Write_Command(Power_control_1);
	TFT_LCD_Write_Data(0xBB);
	TFT_LCD_Write_Data(0x1C);
	TFT_LCD_Write_Data(0x84);

	TFT_LCD_Write_Command(Power_control_2);
	TFT_LCD_Write_Data(0xC0);//default value

	TFT_LCD_Write_Command(Power_control_3); 
	TFT_LCD_Write_Data(0x0A);
	TFT_LCD_Write_Data(0x00);

	TFT_LCD_Write_Command(Power_control_4);     
	TFT_LCD_Write_Data(0x8D);   
	TFT_LCD_Write_Data(0x2A);   

	TFT_LCD_Write_Command(Power_control_5);
	TFT_LCD_Write_Data(0x8D);
	TFT_LCD_Write_Data(0xEE);

	TFT_LCD_Write_Command(VCOM_control_1);     //VCOM
	TFT_LCD_Write_Data(0x06); //1D  .06


	TFT_LCD_Write_Command(Memory_Data_Access_Control);     //MX, MY, RGB mode
	TFT_LCD_Write_Data(0x78);//Set Row and Column exchange and set vertical refrash order
	//	D7	D6	D5	D4	D3	D2	D1	D0
	//	MY	MX	MV	ML	RGB	MH	--	--
	//which:MY:Mirror Y	MX:Mirror X	MV:Exchange X&Y 
	
	TFT_LCD_Write_Command(Interface_Pixel_Format); 
	TFT_LCD_Write_Data(0x06);
	
	
	TFT_LCD_Write_Command(Display_On);     //Display on
	
	TFT_LCD_Fill_Color(0, 160, 0, 80, 0x000000);// clear scren
}


void TFT_LCD_Fill_Color(uint16_t XS, uint16_t XE, uint16_t YS, uint16_t YE, uint32_t Color)
{
	TFT_LCD_Address_Set(XS, XE - 1, YS, YE - 1);
	for(uint16_t i = YS; i < YE; i ++)
	{
		for(uint16_t j = XS; j < XE; j ++)
		{
			TFT_LCD_Write_Data_24Bit(Color);
		}
	}
}

void TFT_LCD_Clear(void)
{
	TFT_LCD_Fill_Color(0, 160, 0, 80, 0x000000);
}

void TFT_LCD_ShowChar(uint16_t XS, uint16_t YS, char Char, TypdefFontSize SizeofChar, uint32_t Color)
{
	uint16_t XE, YE;
	if(SizeofChar == Font8x16)
	{
		XE = XS + 8;
		YE = YS + 16;
	}
	else if(SizeofChar == Font16x16)
	{
		XE = XS + 16;
		YE = YS + 16;
	}
	else
	{
		XE = XS + 8;
		YE = YS + 16;
	}
	TFT_LCD_Address_Set(XS, XE - 1, YS, YE - 1);
	for(uint16_t i = 0; i < YE - YS; i++)
	{
		for(uint16_t j = 0; j < XE - XS; j ++)
		{
			if(TFT_LCD_Font8x16[Char - ' '][i] & (0x01 << j))
				TFT_LCD_Write_Data_24Bit(Color);
			else
				TFT_LCD_Write_Data_24Bit(BLACK);
		}
	}
}

void TFT_LCD_ShowString(uint16_t XS, uint16_t YS, char *String, TypdefFontSize SizeofChar, uint32_t Color)
{
	u16 i = 0;
	while(String[i] != '\0')
	{
		TFT_LCD_ShowChar(XS, YS, String[i], SizeofChar, Color);
		if(SizeofChar == Font8x16)
			XS += 8;
		else if(SizeofChar == Font16x16)
			XS += 16;
		else
			XS += 8;
		i++;
	}
}

uint32_t Pow(uint16_t X, uint16_t Y)
{
	if(!Y)
		return 1;
	return X * Pow(X, Y - 1);
}

void TFT_LCD_ShowNum(uint16_t XS, uint16_t YS, uint32_t Num, uint8_t Length, TypdefFontSize SizeofChar, uint32_t Color)
{
	uint16_t i;
	for(i = 0; i < Length; i ++)
	{
		TFT_LCD_ShowChar(XS, YS, (char)(Num / Pow(10, Length - i - 1) % 10 + '0'), SizeofChar, Color);
		if(SizeofChar == Font8x16)
			XS += 8;
		else if(SizeofChar == Font16x16)
			XS += 16;
		else
			XS += 8;
	}
}

void TFT_LCD_ShowSignNum(uint16_t XS, uint16_t YS, long Num, uint8_t Length, TypdefFontSize SizeofChar, uint32_t Color)
{
	if(Num < 0)
		TFT_LCD_ShowChar(XS, YS, '-', SizeofChar, Color);
	else if(Num > 0)
		TFT_LCD_ShowChar(XS, YS, '+', SizeofChar, Color);
	else
		TFT_LCD_ShowNum(XS, YS, Num, Length, SizeofChar, Color);
	if(SizeofChar == Font8x16)
		XS += 8;
	else if(SizeofChar == Font16x16)
		XS += 16;
	else
		XS += 8;
	TFT_LCD_ShowNum(XS, YS, Num, Length, SizeofChar, Color);
}

void TFT_LCD_ShowBinNum(uint16_t XS, uint16_t YS, uint16_t Num, uint16_t Length, TypdefFontSize SizeofChar, uint32_t Color)
{
	uint16_t i;
	for(i = 0; i < Length; i ++)
	{
		if(!(i % 4) && i)
		{
			TFT_LCD_ShowChar(XS, YS, '_', SizeofChar, Color);
			if(SizeofChar == Font8x16)
				XS += 8;
			else if(SizeofChar == Font16x16)
				XS += 16;
			else
				XS += 8;
		}
		TFT_LCD_ShowChar(XS, YS, Num / Pow(2, Length - i - 1) % 2 + '0', SizeofChar, Color);
		if(SizeofChar == Font8x16)
			XS += 8;
		else if(SizeofChar == Font16x16)
			XS += 16;
		else
			XS += 8;
	}
}
