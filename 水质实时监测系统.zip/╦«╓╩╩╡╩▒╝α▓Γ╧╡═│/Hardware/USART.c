#include "USART.h"

USART_DataStruct _USART2;

void USART1_Config_Init(u32 bond)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 , ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = USART1_RX_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = USART1_TX_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate = bond;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART1, &USART_InitStructure);
	
	USART_Cmd(USART1, ENABLE);
}

void USART1_SendString(char* format, ...)
{
	char str[300] = {0};
	char i = 0;
	va_list func_p;
	va_start(func_p, format);
	vsprintf(str, format, func_p);
	va_end(func_p);
	while(str[i] != '\0')
	{
		while(!USART_GetFlagStatus(USART1, USART_FLAG_TXE));
		USART_SendData(USART1, str[i]);
		i ++;
	}
	while(!USART_GetFlagStatus(USART1, USART_FLAG_TC));
}

void USART2_Config_Init(u32 bond)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 , ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = USART2_RX_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = USART2_TX_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIOA->BSRR = USART2_TX_Pin;
	
	USART_InitStructure.USART_BaudRate = bond;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_Init(USART2, &USART_InitStructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStructure);

	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	USART_ITConfig(USART2, USART_IT_IDLE, ENABLE);
	USART_ClearITPendingBit(USART2, USART_IT_RXNE);
}

void USART2_SendByte(char byte)
{
	while(!USART_GetFlagStatus(USART2, USART_FLAG_TC));
	USART_SendData(USART2, byte);
}

void USART2_SendString(const char *format, ...)
{
	char str[300] = {0};
	char i = 0;
	va_list func_p;
	va_start(func_p, format);
	vsprintf(str, format, func_p);
	va_end(func_p);
	while(str[i] != '\0')
	{
		while(!USART_GetFlagStatus(USART2, USART_FLAG_TXE));
		USART_SendData(USART2, str[i]);
		i ++;
	}
	while(!USART_GetFlagStatus(USART2, USART_FLAG_TC));
}

void USART2_SendString1(const char *format)
{
	while(*format != '\0')
	{
		while(!USART_GetFlagStatus(USART2, USART_FLAG_TXE));
		USART_SendData(USART2, *format);
		format ++;
	}
	while(!USART_GetFlagStatus(USART2, USART_FLAG_TC));
}

void USART2_IRQHandler(void)
{
	static u8 receive_cnt = 0;
	if(USART_GetITStatus(USART2, USART_IT_RXNE) == SET)
	{
		if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == SET)//��USART2->SR
		{
			_USART2.rec_data_arry[receive_cnt] = USART_ReceiveData(USART2);//��USART2->DR
			_USART2.RECEIVE_OK_FLAG = 0;
		}
		receive_cnt ++;
		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	}
	if(USART_GetITStatus(USART2, USART_IT_IDLE) == SET)
	{
		USART2->SR;
		USART2->DR;//�ο��ֲ��У�Ҫ��IDLE���б�־λ���������Ҫ�ȶ�SR�ڶ�DR
		USART_ClearITPendingBit(USART2, USART_IT_IDLE);
		_USART2.rec_data_arry[receive_cnt] = '\0';
		receive_cnt = 0;
		_USART2.RECEIVE_OK_FLAG = 1;//��Ҫ�����ֶ�����
		
		
//		USART1_SendString("%s\r\n", _USART2.rec_data_arry);		
		//����ʹ�ã����俪����ʹ�ô������ֲ鿴USART1���͹���������ȷ��
	}
}

