#ifndef __ADC_H
#define __ADC_H

#include "System.h"

extern u16 ad_value;

void ADC_Config_Init(void);
u16 ADC_GetValue(u8 ADC_Channel);

#endif
