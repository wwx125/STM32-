#ifndef __USART_H
#define __USART_H

#include "System.h"
#include "string.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdarg.h>

#define USART1_RX_Pin GPIO_Pin_10
#define USART1_TX_Pin GPIO_Pin_9

#define USART2_RX_Pin GPIO_Pin_3
#define USART2_TX_Pin GPIO_Pin_2

#define buff_max 1024

typedef struct{
	char rec_data_arry[buff_max];
	volatile bool RECEIVE_OK_FLAG;
}USART_DataStruct;

extern USART_DataStruct _USART2;

void USART1_Config_Init(u32 bond);
void USART1_SendString(char* format, ...);

void USART2_Config_Init(u32 bond);
void USART2_SendByte(char byte);
void USART2_SendString(const char *format, ...);
void USART2_SendString1(const char *format);
void USART2_IRQHandler(void);


#endif
