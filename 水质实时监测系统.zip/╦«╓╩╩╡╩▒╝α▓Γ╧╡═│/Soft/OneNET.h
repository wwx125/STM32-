#ifndef __ONENET_H
#define __ONENET_H

#include "esp8266.h"

typedef struct{
	char Product_ID[20];
	char Device_ID[20];
	char PassWord[200];
}OneNET_MQTT_InitTypDef;

typedef enum{
	_unsigned_char = 0,
	_char,
	_unsigned_int,
	_int,
	_unsigned_long,
	_long,
	_double
}enumDataType;

typedef struct
{
	char TAG[20];
	union
	{
		unsigned char _unsigned_char;
		char _char;
		unsigned int _unsigned_int;
		int _int;
		unsigned long _unsigned_long;
		long _long;
		double _double;	
	}DataType
}OneNET_MQTT_DataFormat;

extern union OneNET_MQTT_StateUnion
{
	u8 Flag_All;
	struct
	{
		volatile bool CFG : 1;		//���ñ�־λ
		volatile bool CONN : 1;		//���ӱ�־λ
		volatile bool REPLY : 1;	//�����־λ
		volatile bool SUB : 1;		//���ı�־λ
	}Flag;
}OneNET_MQTT_State_Reg;


void OneNET_MQTT_Init(OneNET_MQTT_InitTypDef* Structure);
bool OneNET_MQTT_CFG(OneNET_MQTT_InitTypDef* Structure);
bool OneNET_MQTT_CONN(char* str);
bool OneNET_MQTT_SendData(enumDataType datatype, OneNET_MQTT_DataFormat* data);

#endif
