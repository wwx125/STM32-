#include "OneNET.h"

OneNET_MQTT_InitTypDef Structure_Temp;
union OneNET_MQTT_StateUnion OneNET_MQTT_State_Reg;

void OneNET_MQTT_Init(OneNET_MQTT_InitTypDef* Structure)
{
	strcpy(Structure_Temp.Device_ID, Structure->Device_ID);
	strcpy(Structure_Temp.Product_ID, Structure->Product_ID);
	strcpy(Structure_Temp.PassWord, Structure->PassWord);
	
	OneNET_MQTT_CFG(&Structure_Temp);
	
	OneNET_MQTT_State_Reg.Flag.CONN = esp8266_AT_Cmd("OK", "AT+MQTTCONN=0,\"mqtts.heclouds.com\",1883,1");
	
	OneNET_MQTT_State_Reg.Flag.REPLY = esp8266_AT_Cmd("OK", "AT+MQTTSUB=0,\"$sys/%s/%s/thing/property/post/reply\",1", Structure->Product_ID, Structure->Device_ID);
}

bool OneNET_MQTT_CFG(OneNET_MQTT_InitTypDef* Structure)
{
	char cnt = 3;
	char str[300] = {0};
	memset(_USART2.rec_data_arry, 0, sizeof(_USART2.rec_data_arry));
	
	sprintf(str, "AT+MQTTUSERCFG=0,1,\"%s\",\"%s\",\"%s\",0,0,\"\"\r\n", Structure->Device_ID, Structure->Product_ID, Structure->PassWord);
	
	USART2_SendString1(str);
	
	while(!_USART2.RECEIVE_OK_FLAG);
	
	if(strstr(_USART2.rec_data_arry, "OK") != NULL)
	{
		OneNET_MQTT_State_Reg.Flag.CFG = (bool)strstr(_USART2.rec_data_arry, "OK");
		return OneNET_MQTT_State_Reg.Flag.CFG;
	}
	//�鿴�Ƿ�ΪԤ�ڵ���Ӧ
	
	while(cnt)
	{
		cnt --;
		Delay_ms(1000);
		if((bool)strstr(_USART2.rec_data_arry, "OK"))
		{
			break;
		}
		USART2_SendString1(str);
		while(!_USART2.RECEIVE_OK_FLAG);
	}
	OneNET_MQTT_State_Reg.Flag.CFG = (bool)strstr(_USART2.rec_data_arry, "OK");
	return OneNET_MQTT_State_Reg.Flag.CFG;
}


bool OneNET_MQTT_SendData(enumDataType datatype, OneNET_MQTT_DataFormat* data)
{
	char str[200] = {0};
	switch(datatype)
	{
		case _unsigned_char:
			OneNET_MQTT_State_Reg.Flag.SUB = esp8266_AT_Cmd("OK", "AT+MQTTPUB=0,\"$sys/%s/%s/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"%s\\\":{\\\"value\\\":%u\\}}}\",0,0"
											, Structure_Temp.Product_ID, Structure_Temp.Device_ID, data->TAG, data->DataType._unsigned_char);
		break;
		case _char:
			OneNET_MQTT_State_Reg.Flag.SUB = esp8266_AT_Cmd("OK", "AT+MQTTPUB=0,\"$sys/%s/%s/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"%s\\\":{\\\"value\\\":%c\\}}}\",0,0"
							, Structure_Temp.Product_ID, Structure_Temp.Device_ID, data->TAG, data->DataType._char);
		break;
		case _unsigned_int:
			OneNET_MQTT_State_Reg.Flag.SUB = esp8266_AT_Cmd("OK", "AT+MQTTPUB=0,\"$sys/%s/%s/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"%s\\\":{\\\"value\\\":%u\\}}}\",0,0"
							, Structure_Temp.Product_ID, Structure_Temp.Device_ID, data->TAG, data->DataType._unsigned_int);
		break;
		case _int:
			OneNET_MQTT_State_Reg.Flag.SUB = esp8266_AT_Cmd("OK", "AT+MQTTPUB=0,\"$sys/%s/%s/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"%s\\\":{\\\"value\\\":%d\\}}}\",0,0"
							, Structure_Temp.Product_ID, Structure_Temp.Device_ID, data->TAG, data->DataType._int);
		break;
		case _unsigned_long:
			OneNET_MQTT_State_Reg.Flag.SUB = esp8266_AT_Cmd("OK", "AT+MQTTPUB=0,\"$sys/%s/%s/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"%s\\\":{\\\"value\\\":%lu\\}}}\",0,0"
							, Structure_Temp.Product_ID, Structure_Temp.Device_ID, data->TAG, data->DataType._unsigned_long);
		break;
		case _long:
			OneNET_MQTT_State_Reg.Flag.SUB = esp8266_AT_Cmd("OK", "AT+MQTTPUB=0,\"$sys/%s/%s/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"%s\\\":{\\\"value\\\":%l\\}}}\",0,0"
							, Structure_Temp.Product_ID, Structure_Temp.Device_ID, data->TAG, data->DataType._long);
		break;
		case _double:
			OneNET_MQTT_State_Reg.Flag.SUB = esp8266_AT_Cmd("OK", "AT+MQTTPUB=0,\"$sys/%s/%s/thing/property/post\",\"{\\\"id\\\":\\\"123\\\"\\,\\\"params\\\":{\\\"%s\\\":{\\\"value\\\":%.1f\\}}}\",0,0"
							, Structure_Temp.Product_ID, Structure_Temp.Device_ID, data->TAG, data->DataType._double);
		break;
	}
	Delay_ms(500);
	return OneNET_MQTT_State_Reg.Flag.SUB;
}
